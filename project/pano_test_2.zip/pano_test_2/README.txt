Usage: to generate a panorama simply run one of these two scripts,
genFeaturesPanorama.sh or genSIFTPanorama.sh, in a directory with your
images.  Note that there are also two auxiliary scripts,
genFeaturesMatchScript.sh, and genSIFTMatchScript.sh, which generate a
set of commands for matching and aligning the images.

To set the focal length parameters you need to edit the scripts to
change the FOCAL, K1, and K2 variables.  Note that the scripts assume
a complete 360 panorama.

